#include "overlay/node_editor_zh.h"
#include <algorithm>
#include <cassert>
#include <cstring>
#include <iostream>
using namespace NodeGraph;
int main(){
  size_t labels=0;
  for(auto& original:definitions()){
    auto& localized=NodeEditorZh::descriptor(original.kind);
    assert(&original!=&localized);
    assert(original.kind==localized.kind&&original.dataInputs==localized.dataInputs);
    assert(strcmp(original.title,localized.title)!=0);
    assert(strcmp(original.description,localized.description)!=0);
    assert(original.category==localized.category);
    for(size_t i=0;i<original.parameters.size();i++){
      auto& a=original.parameters[i];auto& b=localized.parameters[i];assert(a.key==b.key&&a.defaultValue==b.defaultValue&&a.minValue==b.minValue&&a.maxValue==b.maxValue&&a.kind==b.kind);
      auto n=[](const char* t){return t?std::count(t,t+strlen(t),'|'):-1;};assert(n(a.choices)==n(b.choices));
    }
    for(size_t i=0;i<original.textParameters.size();i++){
      auto& a=original.textParameters[i];auto& b=localized.textParameters[i];assert(a.key==b.key&&a.defaultValue==b.defaultValue&&a.maxLength==b.maxLength);
    }
    auto checkpins=[&](const auto& a,const auto& b){assert(a.size()==b.size());for(size_t i=0;i<a.size();i++){assert(a[i].type==b[i].type&&a[i].defaultParameter==b[i].defaultParameter&&a[i].option==b[i].option); if(strcmp(a[i].name,b[i].name))++labels;}};checkpins(original.inputs,localized.inputs);checkpins(original.outputs,localized.outputs);
  }
  auto g=defaults();std::string data,error,data2;assert(serialize(g,data,error));Workspace g2;assert(deserialize(data,g2,error));assert(serialize(g2,data2,error));assert(data2==data);
  std::cout<<"node types: "<<definitions().size()<<" | translated pin occurrences: "<<labels<<" | stable keys/defaults/types/options: OK | graph round-trip: OK\n";
}
