"""Audit the compiled ai.exe (not just build flags). No dependencies; no GPU used."""
import re
import struct
import sys
from pathlib import Path

def imports(b):
    def u16(o): return struct.unpack_from('<H', b, o)[0]
    def u32(o): return struct.unpack_from('<I', b, o)[0]
    pe = u32(60)
    if b[:2] != b'MZ' or b[pe:pe+4] != b'PE\0\0' or u16(pe+4) != 0x8664 or u16(pe+24) != 0x20b:
        raise ValueError('Not a Windows PE32+ AMD64 executable')
    opt = pe+24
    sections = opt + u16(pe+20)
    def raw(rva):
        for i in range(u16(pe+6)):
            s = sections+40*i
            va, size, offset = struct.unpack_from('<III', b, s+12)
            if va <= rva < va+size: return offset+rva-va
        raise ValueError('Invalid PE RVA: %x' % rva)
    d = raw(u32(opt+120))
    result = set()
    while any(b[d:d+20]):
        n = raw(u32(d+12))
        result.add(b[n:b.index(0,n)].decode('ascii').lower())
        d += 20
    return result

def audit(b):
    names = imports(b)
    if 'onnxruntime.dll' not in names or not any(re.fullmatch(r'opencv_world\d+\.dll', n) for n in names):
        raise ValueError('Missing required ONNX Runtime / OpenCV imports: '+repr(names))
    rejected = [n for n in names if n.startswith(('nvcuda','cudart','cudnn','cublas','nvonnxparser','nvinfer','nvrtc','onnxruntime_providers_cuda','onnxruntime_providers_tensorrt'))]
    if rejected: raise ValueError('Unexpected CUDA/TensorRT imports: '+repr(rejected))
    for label in ('界面不透明度', '性能统计', '输入设备', 'DirectML 直接加载 ONNX 模型，不需要转换引擎。'):
        if label.encode() not in b: raise ValueError('Missing Chinese UTF-8 UI string in ai.exe: '+label)
    print('PASS: x64 ai.exe; ONNX Runtime + OpenCV imported; no CUDA/TensorRT imports; native Chinese overlay strings present.')

if __name__ == '__main__':
    audit(Path(sys.argv[1]).read_bytes())
