Sunone 中文单文件启动器 | DirectML · Windows x64
配套工作流：build-dml.yml。这个 ZIP 是构建材料，不是已经编译出的 EXE。

使用方法
1. 建议在自己的 GitHub 账户新建仓库（例如 sunone-zh）。没有必要修改上游仓库，也不需要个人访问令牌。
2. 在默认分支的仓库根目录上传 DML-zhCN-kit.zip 本身，不要解压、改名或通过 Git LFS 上传。
3. 在同一分支选择 Add file → Create new file，输入 .github/workflows/build-dml.yml，将配套 YAML 的全部文本粘贴进去并提交。
4. 在 Actions 选择“DirectML 中文单文件”，点 Run workflow。工作流使用 Windows 托管运行器；运行额度按你自己的账户设置计算。
5. 运行成功后在该次运行的 Artifacts 下载 Sunone-DML-ZH-Win64；解压得到唯一的 Sunone-DML-ZH.exe。运行摘要中列出该 EXE 的 SHA-256。
6. 在 Windows 10/11 x64 双击 EXE。首次运行会把已内嵌的库和字体释放到当前用户的本地应用数据目录，不要求安装 CUDA/Visual Studio。启动器可打开模型目录；用户需另行放入适配的检测用 .onnx（若有外部权重文件，也要保持相对路径）。打开主程序后 Home 切换设置界面。没有模型时可查看设置。

验证与限制
- 使用上游 DML 入口、Release x64、AIMBOT_USE_CUDA=OFF，不调用 CUDA 构建脚本。原始仓库保留的其他后端源码不会打进成品。
- 工作流检查缓存、加载隔离目录下的 ai.exe --benchmark-help、验证启动器内嵌清单和散列，并扫描主程序的依赖导入与实际 UTF-8 文案。失败不上传 EXE。
- 解包自检不等于 GPU 推理。实际驱动、采集和模型仍需在使用端 Windows 机器确认。此版本未做代码签名。
- 汉化集中在启动器、主窗口、设置、快捷键、节点编辑器和节点说明。设备名、模型名、配置键、控制台和部分底层错误信息保留原文。
- 直接双击 ZIP 或把这两个文件都扔在仓库根目录不会触发 Actions；YAML 的目录必须正确。

构建材料
ui-zh.patch：可阅读的上游源码差异。
pack：C# 启动器、Windows PowerShell 打包脚本、运行说明及部分第三方许可证。
fonts：未经更改的 Noto Sans CJK SC Regular，来自 notofonts/noto-cjk（Sans2.004），连同 SIL Open Font License 1.1。字体 SHA-256：2c76254f6fc379fddfce0a7e84fb5385bb135d3e399294f6eeb6680d0365b74b。
tests：编译后 PE 检查及可独立编译的节点元数据回归检查。
上游：SunOner/sunone_aimbot_2，固定提交 03059d5ed2bc2b30f0140b48c01b8992b3e46ffd，MIT 许可见 LICENSE。
