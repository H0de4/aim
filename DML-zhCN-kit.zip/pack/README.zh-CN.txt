DirectML 单文件启动器 · 技术说明

Package-DML.ps1 仅接受已中文化的源码目录。它调用该项目的 tools/build_dml.ps1，明确以 Release、AIMBOT_USE_CUDA=OFF、AIMBOT_COPY_RUNTIME_DLLS=ON 编译，并从此次生成的 build/dml-zh/Release 取 ai.exe。不接受手动指定的预编译 ai.exe。源码根目录的 fonts 需要有 NotoSansSC-Regular.otf 与 LICENSE.txt。

生成的 Windows x64 EXE 内嵌主程序、字体、运行库和许可证。初次启动不联网、不要求管理员权限，会将文件校验并解包到：
%LOCALAPPDATA%\Sunone-DML-ZH\<清单指纹前24位>\
以后打开同一版本会复用该目录并校验程序文件；正常使用产生的 config.ini、模型、截图不会被重新解包覆盖。不同版本的目录相互独立。可通过“打开模型目录”找到当前版本的 models 子目录；如要迁移自己添加的模型，请连同 ONNX 的外部权重文件一起复制。不要把检测模型放进 depth_models。旧版数据需要先备份，再手动删除不再使用的版本目录。

使用“启动主程序”进入应用；Home 键切换主程序设置窗口。在主程序运行期间关闭启动器窗口只会将它最小化。先从主程序退出，再关闭启动器。没有检测模型也可进入设置；没有内置检测模型。运行 DirectML 推理需要适配 DirectML 的显卡和显卡驱动。启动器依赖 Windows 自带的 .NET Framework（4.7.2 或以上），不包含、不调用 CUDA 安装程序。

验证：在 64 位 Windows PowerShell 中运行
  $p = Start-Process -FilePath ".\Sunone-DML-ZH.exe" -ArgumentList "--verify" -Wait -PassThru
  $p.ExitCode
此模式不启动主程序、不操作输入设备，也不初始化显卡。它在临时目录解包，逐文件核验 SHA-256，并清除临时文件；退出码 0 表示内嵌文件完整，不代表已在特定显卡上验证推理。

Windows 打包流程还会在独立的临时运行目录中，以精简的系统 PATH 执行一次 ai.exe --benchmark-help，要求退出码为 0，且帮助文本包含 DML 专属的 dml-gpu 和 --bench-dml-device。这是原生程序及其 DLL 的加载检查，不测试图形显示或推理精度。只有此检查和启动器的 --verify 都成功才发布 EXE。
