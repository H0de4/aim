# Requires 64-bit Windows PowerShell 5.1, VS C++ x64 build tools + SDK, CMake 3.24+.
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string] $SourceRoot,
    [Parameter(Mandatory)][string] $OutputFile
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
# No web-content script parsing (Windows PowerShell 5.1). Use a script-local defaults copy.
$PSDefaultParameterValues = @{} + $PSDefaultParameterValues
$PSDefaultParameterValues['Invoke-WebRequest:UseBasicParsing'] = $true
$ProgressPreference = 'SilentlyContinue'

function Need-File([string]$Path) {
    if (-not [IO.File]::Exists($Path)) { throw "Missing file: $Path" }
}
function Assert-X64PE([string]$Path) {
    Need-File $Path
    $r = New-Object IO.BinaryReader([IO.File]::OpenRead($Path))
    try {
        if ($r.ReadUInt16() -ne 0x5a4d) { throw "Not a Windows executable: $Path" }
        $r.BaseStream.Position = 0x3c
        $r.BaseStream.Position = $r.ReadUInt32()
        if ($r.ReadUInt32() -ne 0x4550 -or $r.ReadUInt16() -ne 0x8664) { throw "Expected an x64 PE: $Path" }
    } finally { $r.Dispose() }
}
if ($env:OS -ne 'Windows_NT' -or -not [Environment]::Is64BitProcess) {
    throw 'This package must be built in 64-bit Windows PowerShell on Windows x64.'
}
$root = (Get-Item -LiteralPath $SourceRoot).FullName
$out = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($OutputFile)
if ([IO.Path]::GetExtension($out) -ine '.exe') { throw 'OutputFile must end in .exe' }
$csc = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
Need-File $csc
$src = Join-Path $PSScriptRoot 'Launcher.cs'
Need-File $src
Need-File (Join-Path $PSScriptRoot 'notices/imgui.txt')
foreach ($name in 'fonts\NotoSansSC-Regular.otf','fonts\LICENSE.txt','tools\build_dml.ps1','LICENSE') {
    Need-File (Join-Path $root $name)
}
$buildDir = 'build\dml-zh'
$build = Join-Path $root $buildDir
$release = Join-Path $build 'Release'
# Use upstream's DML-only dependency resolver; explicitly disable the CUDA branch and test targets.
& (Join-Path $root 'tools\build_dml.ps1') -RepoRoot $root -BuildDir $buildDir -Configuration Release -NonInteractive -DownloadOrUpdateNeeded $true -ExtraCMakeArgs @('-DAIMBOT_USE_CUDA:BOOL=OFF','-DAIMBOT_COPY_RUNTIME_DLLS:BOOL=ON','-DBUILD_TESTING:BOOL=OFF')
$cache = Get-Content -LiteralPath (Join-Path $build 'CMakeCache.txt')
if (-not ($cache -contains 'AIMBOT_USE_CUDA:BOOL=OFF') -or -not ($cache -contains 'AIMBOT_COPY_RUNTIME_DLLS:BOOL=ON')) {
    throw 'Refusing to package: build cache does not prove a DML-only build with runtime copy enabled.'
}
foreach ($name in 'ai.exe','onnxruntime.dll','DirectML.dll') { Assert-X64PE (Join-Path $release $name) }
$opencv = @(Get-ChildItem -LiteralPath $release -Filter 'opencv_world*.dll' -File | Where-Object Name -match '^opencv_world\d+\.dll$')
if ($opencv.Count -ne 1) { throw 'Expected exactly one non-debug OpenCV world runtime.' }
if (Get-ChildItem -LiteralPath $release -File | Where-Object Name -match '^(cublas|cudart|cudnn|cufft|curand|cusparse|cusolver|nvcuda|nvrtc|nvinfer|nvonnxparser|onnxruntime_providers_(cuda|tensorrt))') {
    throw "Found CUDA or TensorRT files in DML release folder $release. Use a clean checkout."
}

$tmp = Join-Path ([IO.Path]::GetTempPath()) ('sunone-pack-' + [Guid]::NewGuid().ToString('N'))
$stage = Join-Path $tmp 'runtime'
[void][IO.Directory]::CreateDirectory($stage)
try {
    # Explicit release allowlist. No other executables, CUDA DLLs, .engine files, user config or test outputs.
    $runtime = @('ai.exe','DirectML.dll','onnxruntime.dll',$opencv[0].Name)
    foreach ($name in 'onnxruntime_providers_shared.dll','onnxruntime_providers_dml.dll','workflow_mcp.py','ghub_mouse.dll','rzctl.dll') {
        if (Test-Path -LiteralPath (Join-Path $release $name) -PathType Leaf) { $runtime += $name }
    }
    foreach ($name in $runtime) {
        if ($name -like '*.dll') { Assert-X64PE (Join-Path $release $name) }
        Copy-Item -LiteralPath (Join-Path $release $name) -Destination $stage
    }
    # App-local copies of Microsoft's redistributable x64 CRT (not Debug or non-redist binaries).
    $redist = $env:VCToolsRedistDir
    if (-not $redist) {
        $vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
        Need-File $vswhere
        $vs = & $vswhere -latest -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
        if (-not $vs) { throw 'Visual Studio x64 C++ Redistributable files were not found.' }
        $redist = (Get-ChildItem -LiteralPath (Join-Path $vs 'VC\Redist\MSVC') -Directory | Where-Object Name -match '^\d+(\.\d+)+$' | Sort-Object { [version]$_.Name } -Descending | Select-Object -First 1).FullName
    }
    $crt = Get-ChildItem -LiteralPath (Join-Path $redist 'x64') -Directory -Filter 'Microsoft.VC*.CRT' | Select-Object -First 1
    if (-not $crt) { throw 'Install the x64 VC++ build tools including redistributable (CRT) files.' }
    foreach ($dll in (Get-ChildItem -LiteralPath $crt.FullName -File -Filter '*.dll')) {
        Assert-X64PE $dll.FullName
        Copy-Item -LiteralPath $dll.FullName -Destination $stage
    }
    Need-File (Join-Path $stage 'vcruntime140.dll')
    Need-File (Join-Path $stage 'msvcp140.dll')
    $fonts = [IO.Directory]::CreateDirectory((Join-Path $stage 'fonts')).FullName
    foreach ($f in 'NotoSansSC-Regular.otf','LICENSE.txt') { Copy-Item -LiteralPath (Join-Path $root "fonts\$f") -Destination $fonts }
    $notices = [IO.Directory]::CreateDirectory((Join-Path $stage 'licenses')).FullName
    Copy-Item -LiteralPath (Join-Path $root 'LICENSE') -Destination (Join-Path $notices 'SunOner-MIT.txt')
    # Bundle available dependency notices without executing their content.
    $noticeRoots = @('packages','sunone_aimbot_2\modules\serial','sunone_aimbot_2\modules\opencv\build\dml','sunone_aimbot_2\modules\imgui-1.92.8','sunone_aimbot_2\modules\stb','sunone_aimbot_2\modules\makcu')
    foreach ($rel in $noticeRoots) {
        $path = Join-Path $root $rel
        if (-not (Test-Path -LiteralPath $path)) { continue }
        Get-ChildItem -LiteralPath $path -File -Recurse | Where-Object { $_.Name -match '^(LICENSE|LICENCE|COPYING|NOTICE|ThirdPartyNotices?)(\.|-|$)' } | ForEach-Object {
            $id = $_.FullName.Substring($root.Length + 1) -replace '[/\\]','_'
            Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $notices $id)
        }
    }
    Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'notices') -File | ForEach-Object {
        Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $notices $_.Name)
    }
    $stb = Join-Path $root 'sunone_aimbot_2\modules\stb\stb_image.h'
    $simple = Join-Path $root 'sunone_aimbot_2\modules\SimpleIni.h'
    foreach ($f in @($stb,$simple)) {
        if (Test-Path -LiteralPath $f) { Copy-Item -LiteralPath $f -Destination (Join-Path $notices ([IO.Path]::GetFileName($f) + '.txt')) }
    }
    # Native loader smoke test on a disposable staged copy. Avoid accidentally resolving
    # a VS or third-party SDK directory from PATH, and never initialize capture/input.
    $smoke = Join-Path $tmp 'smoke'
    Copy-Item -LiteralPath $stage -Destination $smoke -Recurse
    $stdout = Join-Path $tmp 'smoke-out.txt'
    $stderr = Join-Path $tmp 'smoke-err.txt'
    $oldPath = $env:Path
    try {
        $env:Path = (Join-Path $env:WINDIR 'System32') + ';' + $env:WINDIR
        $proc = Start-Process -FilePath (Join-Path $smoke 'ai.exe') -ArgumentList '--benchmark-help' -WorkingDirectory $smoke -NoNewWindow -PassThru -RedirectStandardOutput $stdout -RedirectStandardError $stderr
        $null = $proc.Handle
        if (-not $proc.WaitForExit(60000)) { $proc.Kill(); $proc.WaitForExit(); throw 'DML loader smoke test timed out.' }
        $proc.WaitForExit()
        $helpText = [IO.File]::ReadAllText($stdout)
        if ($proc.ExitCode -ne 0 -or $helpText -notmatch 'dml-gpu' -or $helpText -notmatch '--bench-dml-device') {
            throw ("DML loader help test failed. Exit=" + $proc.ExitCode + "; stdout=" + $helpText + "; stderr=" + [IO.File]::ReadAllText($stderr))
        }
        Write-Host 'Verified native help from staged ai.exe: dml-gpu, --bench-dml-device.'
    } finally { $env:Path = $oldPath }
    Remove-Item -LiteralPath $smoke -Recurse -Force
    $hashes = @(Get-ChildItem -LiteralPath $stage -File -Recurse | Sort-Object FullName | ForEach-Object {
        $name = $_.FullName.Substring($stage.Length + 1).Replace('\','/')
        (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant() + "`t" + $name
    })
    [IO.File]::WriteAllLines((Join-Path $tmp 'payload.tsv'), [string[]]$hashes, (New-Object Text.UTF8Encoding($false)))
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [IO.Compression.ZipFile]::CreateFromDirectory($stage,(Join-Path $tmp 'payload.zip'),[IO.Compression.CompressionLevel]::Optimal,$false)
    $bat = Join-Path $tmp 'Sunone-DML-ZH.exe'
    Push-Location -LiteralPath $tmp
    try {
        & $csc /nologo /langversion:5 /codepage:65001 /optimize+ /target:winexe /platform:x64 '/r:System.Windows.Forms.dll' '/r:System.Drawing.dll' '/r:System.IO.Compression.dll' '/resource:payload.zip,Sunone.Payload.Zip' '/resource:payload.tsv,Sunone.Payload.Manifest' '/out:Sunone-DML-ZH.exe' $src
        if ($LASTEXITCODE -ne 0) { throw "C# launcher compilation failed: $LASTEXITCODE" }
        Assert-X64PE $bat
        # A package cannot pass this step with an empty/online-only bootstrapper:
        # --verify extracts and hashes every embedded file without starting the main program.
        $p = Start-Process -FilePath $bat -ArgumentList '--verify' -Wait -PassThru
        if ($p.ExitCode -ne 0) { throw "Embedded payload self-test failed: $($p.ExitCode)" }
    } finally { Pop-Location }
    [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($out))
    $pending = $out + '.' + [Guid]::NewGuid().ToString('N') + '.tmp'
    try {
        [IO.File]::Copy($bat,$pending)
        if ([IO.File]::Exists($out)) { [IO.File]::Replace($pending,$out,$null) } else { [IO.File]::Move($pending,$out) }
    } finally { if ([IO.File]::Exists($pending)) { [IO.File]::Delete($pending) } }
    Write-Host ("DirectML x64 EXE: " + $out)
    Write-Host ("SHA256: " + (Get-FileHash -LiteralPath $out -Algorithm SHA256).Hash)
} finally {
    if (Test-Path -LiteralPath $tmp) { Remove-Item -LiteralPath $tmp -Force -Recurse }
}
