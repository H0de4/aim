using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Threading.Tasks;

internal static class Payload {
    const string manifestName = "Sunone.Payload.Manifest";
    const string archiveName = "Sunone.Payload.Zip";
    static Stream Resource(string name) {
        Stream s = typeof(Payload).Assembly.GetManifestResourceStream(name);
        if (s == null) throw new InvalidDataException("缺少内嵌资源：" + name);
        return s;
    }
    static string Hash(Stream s) {
        using (var sha = SHA256.Create()) {
            return BitConverter.ToString(sha.ComputeHash(s)).Replace("-", "").ToLowerInvariant();
        }
    }
    public static string Id() { using (var s = Resource(manifestName)) return Hash(s); }
    public static string Runtime(string id) {
        return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                            "Sunone-DML-ZH", id.Substring(0, 24));
    }
    // Both the generated manifest and the archive must agree on names and digests.
    // The extractor only accepts regular relative paths in this release.
    static string Destination(string root, string name) {
        if (name.Length == 0 || name.Contains("\\") || name.Contains(":") || Path.IsPathRooted(name))
            throw new InvalidDataException("无效的文件路径：" + name);
        foreach (string part in name.Split('/')) {
            if (part.Length == 0 || part == "." || part == ".." ||
                part.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0)
                throw new InvalidDataException("无效的文件名：" + name);
        }
        string prefix = Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
        string path = Path.GetFullPath(Path.Combine(root, name.Replace('/', Path.DirectorySeparatorChar)));
        if (!path.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("文件不在运行目录内：" + name);
        return path;
    }
    static Dictionary<string,string> Manifest() {
        var result = new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);
        using (var s = Resource(manifestName))
        using (var r = new StreamReader(s, Encoding.UTF8, true)) {
            string line;
            while ((line = r.ReadLine()) != null) {
                string[] fields = line.Split('\t');
                if (fields.Length != 2 || fields[0].Length != 64) throw new InvalidDataException("文件清单无效。");
                result.Add(fields[1], fields[0]);
            }
        }
        foreach (string name in new[] {"ai.exe", "onnxruntime.dll", "DirectML.dll", "fonts/NotoSansSC-Regular.otf"})
            if (!result.ContainsKey(name)) throw new InvalidDataException("缺少运行文件：" + name);
        return result;
    }
    static bool Matches(string path, string expected) {
        if (!File.Exists(path)) return false;
        using (var s = File.OpenRead(path)) return String.Equals(Hash(s), expected, StringComparison.OrdinalIgnoreCase);
    }
    static void Materialize(string dir) {
        var records = Manifest();
        using (var s = Resource(archiveName))
        using (var zip = new ZipArchive(s, ZipArchiveMode.Read, false)) {
            foreach (var entry in zip.Entries) {
                string name = entry.FullName.Replace('\\','/');
                string dest = Destination(dir, name), expected;
                if (!records.TryGetValue(name, out expected))
                    throw new InvalidDataException("压缩包与文件清单不匹配：" + name);
                records.Remove(name);
                if (Matches(dest, expected)) continue;
                Directory.CreateDirectory(Path.GetDirectoryName(dest));
                string pending = dest + "." + Guid.NewGuid().ToString("N") + ".tmp";
                try {
                    using (var src = entry.Open())
                    using (var output = new FileStream(pending, FileMode.CreateNew, FileAccess.Write, FileShare.None)) {
                        src.CopyTo(output);
                    }
                    if (!Matches(pending, expected)) throw new InvalidDataException("文件校验失败：" + name);
                    if (File.Exists(dest)) File.Replace(pending, dest, null);
                    else File.Move(pending, dest);
                } finally { if (File.Exists(pending)) File.Delete(pending); }
            }
            if (records.Count != 0) throw new InvalidDataException("内嵌压缩包不完整。");
        }
        Directory.CreateDirectory(Path.Combine(dir,"models"));
        Directory.CreateDirectory(Path.Combine(dir,"depth_models"));
    }
    public static void Prepare(string root) {
        if (Directory.Exists(root)) { Materialize(root); return; }
        string parent = Path.GetDirectoryName(root);
        Directory.CreateDirectory(parent);
        string staging = Path.Combine(parent, "new-" + Guid.NewGuid().ToString("N"));
        try { Directory.CreateDirectory(staging); Materialize(staging); Directory.Move(staging, root); }
        finally { if (Directory.Exists(staging)) Directory.Delete(staging,true); }
    }
    public static void Verify() {
        string parent = Path.Combine(Path.GetTempPath(), "Sunone-verify-" + Guid.NewGuid().ToString("N"));
        try { Prepare(Path.Combine(parent,"runtime")); }
        finally { if (Directory.Exists(parent)) Directory.Delete(parent, true); }
    }
}

internal sealed class LauncherForm : Form {
    readonly Label status = new Label();
    readonly Button run = new Button(), models = new Button();
    readonly string root;
    Process child;
    async void LoadFiles(object sender, EventArgs args) {
        try {
            await Task.Run((Action)delegate { Payload.Prepare(root); });
            run.Enabled = models.Enabled = true;
            status.Text = Directory.GetFiles(Path.Combine(root,"models"), "*.onnx").Length == 0 ?
                "尚未添加检测模型。可先打开模型目录放入 .onnx 文件，也可直接启动。" :
                "已就绪。启动后按 Home 键切换主程序设置界面。";
        } catch (Exception ex) { status.Text = "准备运行文件失败：" + ex.Message; }
    }
    internal LauncherForm(string root) {
        this.root = root;
        Text = "Sunone · DirectML 启动器";
        Font = new Font("Microsoft YaHei UI", 10f);
        AutoScaleMode = AutoScaleMode.Dpi; StartPosition = FormStartPosition.CenterScreen;
        ClientSize = new Size(530, 218); FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        var heading = new Label { Text = "Sunone  /  DirectML", Font=new Font(Font.FontFamily,18f,FontStyle.Bold),
                                  AutoSize=true, Location=new Point(20,16) };
        var details = new Label { Text = "简体中文版    ·    Windows x64    ·    无需 CUDA",
                                  AutoSize=true, Location=new Point(22,62) };
        status.SetBounds(22,94,486,61); status.Text = "正在校验并准备运行文件，首次启动可能需要片刻…";
        run.Text = "启动主程序"; run.SetBounds(22,162,142,36); run.Enabled = false;
        run.Click += delegate {
            try {
                var psi = new ProcessStartInfo(Path.Combine(root, "ai.exe"));
                psi.WorkingDirectory = root; psi.UseShellExecute = false;
                child = new Process(); child.StartInfo = psi; child.EnableRaisingEvents = true;
                child.SynchronizingObject = this;
                child.Exited += delegate {
                    int code = child.ExitCode;
                    child.Dispose(); child = null;
                    run.Enabled = true; status.Text = code == 0 ? "主程序已退出。" :
                        "主程序异常退出（代码 0x" + code.ToString("X8") + "）。请检查系统版本、显卡驱动和模型。";
                };
                if (!child.Start()) throw new Exception("无法创建进程。");
                run.Enabled = false; status.Text = "主程序正在运行。按 Home 键打开或关闭设置界面。";
            } catch (Exception ex) { if(child != null) child.Dispose(); child = null; run.Enabled = true;
                status.Text = "启动失败：" + ex.Message; }
        };
        models.Text = "打开模型目录"; models.SetBounds(176,162,146,36); models.Enabled=false;
        models.Click += delegate {
            try { Process.Start(new ProcessStartInfo(Path.Combine(root,"models")) {UseShellExecute=true}); }
            catch (Exception ex) { status.Text="不能打开目录：" + ex.Message; }
        };
        Controls.AddRange(new Control[] {heading, details, status, run, models});
        AcceptButton = run; Shown += LoadFiles;
        FormClosing += delegate(object sender, FormClosingEventArgs e) {
            if (child != null && !child.HasExited && e.CloseReason == CloseReason.UserClosing) {
                e.Cancel = true; WindowState = FormWindowState.Minimized;
            }
        };
    }
}
internal static class Program {
    [STAThread] static int Main(string[] args) {
        bool verify = args.Length == 1 && args[0] == "--verify";
        try {
            if (verify) { Payload.Verify(); Console.WriteLine("Verified embedded DirectML x64 payload."); return 0; }
            if (args.Length != 0) return 2;
            string id = Payload.Id(); bool created;
            using (var mutex = new Mutex(true, @"Local\Sunone-DML-" + id, out created)) {
                if (!created) {
                    MessageBox.Show("启动器已打开，请查看任务栏。", "DirectML 启动器");
                    return 0;
                }
                Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new LauncherForm(Payload.Runtime(id)));
            }
            return 0;
        } catch (Exception ex) {
            if (verify) Console.Error.WriteLine(ex.ToString());
            else MessageBox.Show(ex.Message, "启动失败", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return 1;
        }
    }
}
